After outlining objects manually using GIMP, transform these outlines into a label image or set of masks with the `objects_from_gimp_outlines.cppipe` CellProfiler pipeline.
